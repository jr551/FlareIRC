#include "talkwindow.h"
#include "ui_talkwindow.h"
#include "chattab.h"
#include <qmessagebox.h>
TalkWindow::TalkWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::TalkWindow)
{
    ui->setupUi(this);

    ircConnection = new IRCConnection("irc.gamesurge.net", 6667, "FreemanTesting");
    ircConnection->Connect();

    connect(ircConnection, SIGNAL(IRC_Connected()), this, SLOT(IRC_Connected()));
    connect(ircConnection, SIGNAL(IRC_ServerMessage(QString)), this, SLOT(IRC_ServerMessage(QString)));
    connect(ircConnection, SIGNAL(IRC_JoinedChannel(QString,QString)), this, SLOT(IRC_JoinedChannel(QString, QString)));
    connect(ircConnection, SIGNAL(IRC_PrivateMessage(QString, QString)), this, SLOT(IRC_PrivateMessage(QString, QString)));
    connect(ircConnection, SIGNAL(IRC_ChannelMessage(QString, QString, QString, bool)), this, SLOT(IRC_ChannelMessage(QString, QString, QString, bool)));
    connect(ircConnection, SIGNAL(IRC_LeftChannel(QString, QString, QString)), this, SLOT(IRC_LeftChannel(QString, QString, QString)));
    connect(ircConnection, SIGNAL(IRC_ModeChange(QString, QString, QString, QString)), this, SLOT(IRC_ModeChange(QString, QString, QString, QString)));
    connect(ircConnection, SIGNAL(IRC_UserList(QString,QStringList)), this, SLOT(IRC_UserList(QString, QStringList)));
    connect(ircConnection, SIGNAL(IRC_Kick(QString,QString,QString,QString)), this, SLOT(IRC_Kick(QString, QString,QString,QString)));
    connect(ircConnection, SIGNAL(IRC_ChannelTopic(QString,QString)), this, SLOT(IRC_ChannelTopic(QString, QString)));


}
/*
  QT Signals;

    void IRC_Connected();
    void IRC_JoinedChannel( QString channel );
    void IRC_PrivateMessage( QString source, QString msg );
    void IRC_ServerMessage( QString msg );
*/
TalkWindow::~TalkWindow()
{
    delete ui;
}

void TalkWindow::changeEvent(QEvent *e)
{
    QMainWindow::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}


void TalkWindow::IRC_ServerMessage( QString msg )
{
    ui->txtServerMessages->append(msg);


}

void TalkWindow::IRC_Connected()
{

}

void TalkWindow::IRC_JoinedChannel( QString source, QString channel )
{
    if ( source.compare( tr( ircConnection->getNick()), Qt::CaseInsensitive ) == 0 )
    {
        ui->txtChannelJoin->text().clear();
        ChatTab *t = new ChatTab(ui->tabChats, this, ui->txtChannelJoin->text());
        ui->tabChats->addTab( t, ui->txtChannelJoin->text());
        return;
    }


    ChatTab *tb = (ChatTab*)FindTabForChannel(channel);
    if (!tb)
        return;
    tb->AddUser(source);
    tb->AddChatLine( "<FONT COLOR='green'><b>" + source + "</b> joined the channel</FONT>");

    //ui->txtMessages->append("*Joining* (" + channel+ ") " + source);
}
void TalkWindow::IRC_UserList( QString channel, QStringList users)
{
    ChatTab *tb = (ChatTab*)FindTabForChannel(channel);
    if (!tb)
        return;

    QStringListIterator itUsers(users);
       while (itUsers.hasNext())
           tb->AddUser(itUsers.next());
}

void TalkWindow::IRC_ModeChange( QString source, QString channel, QString whom, QString modes  )
{
    ChatTab *tb = (ChatTab*)FindTabForChannel(channel);
    if (!tb)
        return;

    tb->AddChatLine("<FONT COLOR='purple'><b>" + source + "</b> set mode(s) " + modes + " on <b>" + whom + "</b></FONT>");

    if ( modes.compare(tr("+o"), Qt::CaseInsensitive) == 0 )
        tb->EditUser(whom, "@"+whom);
    else if ( modes.compare(tr("+v"), Qt::CaseInsensitive) == 0 )
        tb->EditUser(whom, "+"+whom);
    else if ( modes.compare(tr("-v"), Qt::CaseInsensitive) == 0 )
        tb->EditUser(whom, whom);
    else if ( modes.compare(tr("-o"), Qt::CaseInsensitive) == 0 )
        tb->EditUser(whom, whom);

}
void TalkWindow::IRC_LeftChannel( QString source, QString channel, QString quitMsg  )
{
    ChatTab *tb = (ChatTab*)FindTabForChannel(channel);

    if (!tb)
        return;

    tb->RemoveUser(source);
    tb->AddChatLine( "<FONT COLOR='red'><b>" + source + "</b> left the channel (" + quitMsg + ")</FONT>");

}

void TalkWindow::IRC_Kick( QString source, QString channel, QString whom, QString message )
{
    ChatTab *tb = (ChatTab*)FindTabForChannel(channel);

    if (!tb)
        return;

    if ( whom.compare( tr( ircConnection->getNick()), Qt::CaseInsensitive ) == 0 )
    {
        QMessageBox::information(NULL, tr("FlareIRC - Kick."), "You were kicked from " + channel + " by " + source + " (" + message + ")");
        on_tabChats_tabCloseRequested(ui->tabChats->indexOf(tb));
        return;
    }

    tb->AddChatLine( "<FONT COLOR='red'><b>" + whom + "</b> was kicked by <b>" + source + "</b> reason: (" + message + ")</FONT>");
    tb->RemoveUser(whom);



}

void TalkWindow::IRC_ChannelMessage( QString source, QString context, QString msg, bool action )
{

    ChatTab *tb = (ChatTab*)FindTabForChannel(context);

    if (!tb)
        return;

    if ( action )
        tb->AddChatLine("<FONT COLOR='#FF0066'><b> **" + source + " " + msg + "** </b></FONT>");
    else
        tb->AddChatLine("<FONT COLOR='#666'><b>" +source + "</b></FONT>: " + msg);

}

void TalkWindow::IRC_PrivateMessage( QString source, QString msg )
{
    //ui->txtMessages->append(source+": "+msg);
}

QWidget* TalkWindow::FindTabForChannel( QString channel )
{
    for ( int i = 0; i < ui->tabChats->count(); i++ )
    {
        if ( ui->tabChats->tabText(i).compare(channel, Qt::CaseInsensitive ) == 0 )
            return ui->tabChats->widget(i);
    }
    return NULL;
}

void TalkWindow::SendMessage( QString channel, QString message )
{
    ircConnection->PrivMsg( channel.toAscii(), message.toAscii() );

    ChatTab *tb = (ChatTab*)FindTabForChannel(channel);
    if (!tb)
        return;
    if ( message.startsWith("/me ") )
    {
        tb->AddChatLine("<FONT COLOR='#FF0066'><b> ** FreemanTesting " + message.mid(3) + "** </b></FONT>");
    }
    else
        tb->AddChatLine("<b>FreemanTesting:</b> " + message );
}
void TalkWindow::IRC_ChannelTopic( QString channel, QString topic)
{
    ChatTab *tb = (ChatTab*)FindTabForChannel(channel);
    if (!tb)
        return;
    tb->AddChatLine("<FONT COLOR='#9999CC'><i> Topic: " + topic + "</i></FONT>" );
}

void TalkWindow::on_btnJoin_clicked()
{
    ircConnection->JoinChannel( ui->txtChannelJoin->text().toAscii());

}

void TalkWindow::on_tabChats_tabCloseRequested(int index)
{
    if ( ui->tabChats->tabText(index).compare( tr("Server"), Qt::CaseInsensitive) == 0 )
        return;


    ircConnection->LeaveChannel(ui->tabChats->tabText(index).toAscii());
    ui->tabChats->removeTab(index);
}
