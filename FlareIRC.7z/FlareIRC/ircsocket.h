#ifndef IRCSOCKET_H
#define IRCSOCKET_H

#include <QTCPSocket>
#include <QList>
#include <QStringList>

class IRCConnection : public QObject
{
    Q_OBJECT
public:
    IRCConnection( const char* server, int port, const char* nick );
    bool Connect( );
    void SendRawData( const char* data );
    void JoinChannel( const char* channel );
    void PrivMsg( const char* to, const char* message );
    void LeaveChannel( const char* channel );
    void Login();

    const char* getServer(){ return szServer; }
    const char* getNick(){ return szNick; }
private:
    const char* szServer;
    const char* szNick;
    int iPort;
    QTcpSocket* qSocket;
    bool bConnecting;
    QList<const char*> lsChannels;

protected:
   // qint64 readData(char *data, qint64 maxSize);
private slots:
    void Connection_ReadyRead();
    void displayError(QAbstractSocket::SocketError socketError);


    void Connection_Connected();
    void Connection_Disconnected();
    void Connection_StateChanged( QAbstractSocket::SocketState socketState );

signals:
    void IRC_Connected();
    void IRC_Disconnected();

    void IRC_JoinedChannel( QString source, QString channel );
    void IRC_LeftChannel( QString source, QString channel, QString quitMsg  );

    void IRC_ModeChange( QString source, QString channel, QString whom, QString modes  );

    void IRC_ChannelMessage( QString source, QString context, QString msg, bool action );
    void IRC_PrivateMessage( QString source, QString msg );
    void IRC_ServerMessage( QString msg );

    void IRC_Kick( QString source, QString channel, QString whom, QString message );

    void IRC_NickChange( QString oldNick, QString newNick );
    void IRC_UserList( QString channel, QStringList users);
    void IRC_ChannelTopic( QString channel, QString topic);
};

#endif // IRCSOCKET_H
