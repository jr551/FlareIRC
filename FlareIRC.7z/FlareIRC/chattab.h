#ifndef CHATTAB_H
#define CHATTAB_H

#include <QWidget>
#include "talkwindow.h"
#include <QStandardItemModel>

namespace Ui {
    class ChatTab;
}
enum eIRCUserModes
{
    UMODE_OP = 0,
    UMODE_VOICE,
    UMODE_NONE
};

class IRCUserItem : public QObject, public QStandardItem
{
    Q_OBJECT
public:
    IRCUserItem( QString usersName, eIRCUserModes mode )
        : QStandardItem("")
    {
        uMode = mode;
        userName = usersName;
        setText(userName + getPostFixForMode());
    }
    void ChangeMode( eIRCUserModes mode )
    {
        uMode = mode;
        setText(userName + getPostFixForMode());
    }
    eIRCUserModes getUsersMode() { return uMode; }
    QString getUserName( ){ return userName;}
private:
    const char *getPostFixForMode()
    {
        if ( uMode == UMODE_OP)
            return " (Op)";
        else if ( uMode == UMODE_VOICE)
            return " (Voiced)";
        return "";
    }
    QString userName;
    eIRCUserModes uMode;
};

class ChatTab : public QWidget {
    Q_OBJECT
public:
    ChatTab(QWidget *parent = 0, TalkWindow *pTalkWindow = 0, QString tChannel = tr("null"));
    ~ChatTab();

    void AddChatLine( QString line );
    void AddUser( QString user );
    void RemoveUser( QString user );
    void EditUser( QString oldUser, QString newUser );

protected:
    void changeEvent(QEvent *e);

private:
    Ui::ChatTab *ui;
    TalkWindow *talkWindow;
    QString channel;
    QStandardItemModel *dmUsers;

private slots:
    void on_txtChat_returnPressed();
};

#endif // CHATTAB_H
