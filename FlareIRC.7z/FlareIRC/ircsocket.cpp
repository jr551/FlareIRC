#include "ircsocket.h"
#include <qmessagebox.h>
#include <QHostAddress>
#include <QTextStream>

IRCConnection::IRCConnection( const char* server, int port, const char* nick )
{
    szServer = server;
    iPort = port;
    szNick = nick;
    qSocket = new QTcpSocket(this);
    bConnecting = false;

    connect(qSocket, SIGNAL(readyRead()), this, SLOT(Connection_ReadyRead()));
    connect(qSocket, SIGNAL(error(QAbstractSocket::SocketError)), this, SLOT(displayError(QAbstractSocket::SocketError)));
    connect(qSocket, SIGNAL(connected()), this, SLOT(Connection_Connected()));
    connect(qSocket, SIGNAL(disconnected()), this, SLOT(Connection_Disconnected()));
    connect(qSocket, SIGNAL(stateChanged(QAbstractSocket::SocketState)), this, SLOT(Connection_StateChanged(QAbstractSocket::SocketState)));
}

/*
  QT Signals;

    void IRC_Connected();
    void IRC_JoinedChannel( QString channel );
    void IRC_PrivateMessage( QString source, QString msg );
    void IRC_ServerMessage( QString msg );
*/


bool IRCConnection::Connect( )
{
    qSocket->connectToHost( szServer, iPort );
    return true;
}

void IRCConnection::Connection_Connected()
{
    Login();
    emit IRC_Connected();
}

void IRCConnection::JoinChannel( const char* channel )
{
    char joinString[128];
    snprintf(joinString, sizeof(joinString), "JOIN %s\r\n", channel);
    qSocket->write(joinString);
    lsChannels.append(channel);
}

void IRCConnection::PrivMsg( const char* to, const char* message )
{
    char msgString[256];
    snprintf(msgString, sizeof(msgString), "PRIVMSG %s :%s\r\n", to, message);
    SendRawData(msgString);
}

void IRCConnection::Login()
{
    char nickString[128];
    snprintf(nickString, sizeof(nickString), "NICK %s\r\n", szNick);
    qSocket->write(nickString);

    char userString[128];
    snprintf(userString, sizeof(userString), "USER %s * %s :FlareIRC C++ Client\r\n", szNick, szServer );
    qSocket->write(userString);

}

void IRCConnection::Connection_Disconnected()
{
   // QMessageBox::information(NULL, tr("FlareIRC"), tr("IRCSocket::Connection_Disconnected()"));
    emit IRC_Disconnected();
}
void IRCConnection::Connection_StateChanged( QAbstractSocket::SocketState socketState )
{
    QString st;
    st.setNum(socketState);
    if (socketState == 3 )
    {

    }
   // QMessageBox::information(NULL,  tr("FlareIRC"),tr("IRCSocket::Connection_StateChanged() ") + st );
}

void IRCConnection::LeaveChannel( const char* channel )
{
    char dataString[256];
    snprintf(dataString, sizeof(dataString), "PART %s :Leaving - FlareIRC C++ Prototype\r\n", channel);
    qSocket->write(dataString);
}

void IRCConnection::SendRawData( const char* data )
{
    char dataString[256];
    snprintf(dataString, sizeof(dataString), "%s\r\n", data);
    qSocket->write(dataString);
}

void IRCConnection::Connection_ReadyRead()
{
    QTextStream stream(qSocket);
    QString data;
    bool bold = false;
    
    do
    {
        bold = !bold;
        data = stream.readLine();
        if (data.isNull())
            break;



        QStringList lst = data.split(tr(" "));
        QStringList lstParam = data.split(tr(":"));
        QStringList lstExcla = lst.first().split(tr("!"));

        if ( lst.size() > 0 && lst.at(0).compare(tr("PING"), Qt::CaseInsensitive) == 0 && !lstParam.isEmpty())
        {
            QString pingReply ("PONG "+lst.last()+"\r\n");
            qSocket->write(pingReply.toAscii());
        }

       // char a[1024];
       // snprintf( a, sizeof(a), "<b>%s</b>", data )
       // if (bold)
       //     emit IRC_ServerMessage("<b>" + data + "</b>");
       // else
       //     emit IRC_ServerMessage(data) ;
        //continue;

        if ( lst.size() > 1 && lst.at(1).compare(tr("JOIN"), Qt::CaseInsensitive) == 0 && !lstParam.isEmpty())
        {
            emit IRC_JoinedChannel( lstExcla.first().mid(1), lst.last() );
        }
        else if ( lst.size() > 1 && lst.at(1).compare(tr("PART"), Qt::CaseInsensitive) == 0 && !lstParam.isEmpty())
        {
            emit IRC_LeftChannel( lstExcla.first().mid(1), lst.at(2), lstParam.last() );
        }
        else if ( lst.size() > 4 && lst.at(1).compare(tr("MODE"), Qt::CaseInsensitive) == 0 && !lstParam.isEmpty())
        {
            emit IRC_ModeChange( lstExcla.first().mid(1), lst.at(2), lst.at(4), lst.at(3) );
        }
        else if ( lst.size() > 3 && lst.at(1).compare(tr("KICK"), Qt::CaseInsensitive) == 0 && !lstParam.isEmpty())
        {
             emit IRC_Kick( lstExcla.first().mid(1), lst.at(2), lst.at(3), lstParam.last() );
        }
        else if ( lst.size() > 2 && lst.at(1).compare(tr("PRIVMSG"), Qt::CaseInsensitive) == 0 && !lstParam.isEmpty() && lst.at(2).contains(tr("#")) )
        {
            if ( lstParam.last().contains( "ACTION" ) )
            {
                QString actionMessage = lstParam.last().mid(7);
                actionMessage.chop(1);
                emit IRC_ChannelMessage( lstExcla.first().mid(1), lst.at(2), actionMessage, true);
            }
            else
                emit IRC_ChannelMessage( lstExcla.first().mid(1), lst.at(2), lstParam.last(), false);

        }
        else if ( lst.size() > 2 && lst.at(1).compare(tr("PRIVMSG"), Qt::CaseInsensitive) == 0 && !lstParam.isEmpty())
        {
            emit IRC_PrivateMessage( lstExcla.first().mid(1), lstParam.last());
        }
        else if ( lst.size() > 1 && lst.at(1).compare(tr("353"), Qt::CaseInsensitive) == 0 && !lstParam.isEmpty()) //353   RPL_NAMREPLY
        {
            QStringList lstUsers = lstParam.last().split(tr(" "));
            emit IRC_UserList( lst.at(4), lstUsers);
        }
        else if ( lst.size() > 1 && lst.at(1).compare(tr("332"), Qt::CaseInsensitive) == 0 && !lstParam.isEmpty()) //332  topic
        {
            emit  IRC_ChannelTopic( lst.at(3), lstParam.last());
        }
        else if ( lst.size() > 1 && lst.at(1).compare(tr("TOPIC"), Qt::CaseInsensitive) == 0 && !lstParam.isEmpty()) //  topic
        {
            emit  IRC_ChannelTopic( lst.at(2), lstParam.last());
        }


        emit IRC_ServerMessage(data);

    } while ( !data.isNull() );


    return;

}

void IRCConnection::displayError(QAbstractSocket::SocketError socketError)
{
       switch (socketError) {
       case QAbstractSocket::RemoteHostClosedError:
           break;
       case QAbstractSocket::HostNotFoundError:
           QMessageBox::information(NULL, tr("Fortune Client"),
                                    tr("The host was not found. Please check the "
                                       "host name and port settings."));
           break;
       case QAbstractSocket::ConnectionRefusedError:
           QMessageBox::information(NULL, tr("Fortune Client"),
                                    tr("The connection was refused by the peer. "
                                       "Make sure the fortune server is running, "
                                       "and check that the host name and port "
                                       "settings are correct."));
           break;
       default:
           QMessageBox::information(NULL, tr("Fortune Client"),
                                    tr("The following error occurred: %1.")
                                    .arg(qSocket->errorString()));
       }

       //getFortuneButton->setEnabled(true);
}
/*

qint64 IRCSocket::readData(char *data, qint64 maxSize)
{
    QMessageBox::information( NULL, "Application name",
                                "Unable to find the user preferences file.\n"
                                "The factory default will be used instead." );

    return QTcpSocket::readData( data, maxSize );
}
*/
