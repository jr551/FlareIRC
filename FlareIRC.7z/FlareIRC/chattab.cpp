#include "chattab.h"
#include "ui_chattab.h"


ChatTab::ChatTab(QWidget *parent, TalkWindow *pTalkWindow, QString tChannel) :
    QWidget(parent),
    ui(new Ui::ChatTab)
{
    channel = tChannel;
    talkWindow = pTalkWindow;
    ui->setupUi(this);
    dmUsers = new QStandardItemModel(this);
    ui->lstUsers->setModel(dmUsers);
}

ChatTab::~ChatTab()
{
    delete ui;
}

void ChatTab::changeEvent(QEvent *e)
{
    QWidget::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}

void ChatTab:: AddChatLine( QString line )
{
    ui->txtMessages->append(line);
}

void ChatTab::AddUser( QString user )
{
    if ( user.mid(0,1).compare("@") == 0 )
        dmUsers->appendRow( new IRCUserItem( user.mid(1), UMODE_OP) );
    else if ( user.mid(0,1).compare("+") == 0 )
        dmUsers->appendRow( new IRCUserItem( user.mid(1), UMODE_VOICE) );
    else
        dmUsers->appendRow( new IRCUserItem( user, UMODE_NONE) );

    dmUsers->sort(0, Qt::AscendingOrder);

}
void ChatTab::RemoveUser( QString user )
{
    for ( int i = 0; i < dmUsers->rowCount(); i++ )
    {
        IRCUserItem *ircUser = (IRCUserItem*)dmUsers->item(i,0);
        if (!ircUser)
            continue;
        QString cUser = ircUser->getUserName();
        if ( cUser.compare(user, Qt::CaseInsensitive) == 0 /*|| cUser.mid(1).compare(user, Qt::CaseInsensitive) == 0*/)
        {
            dmUsers->removeRow(i); 
        }
    }

    dmUsers->sort(0, Qt::AscendingOrder);

}
void ChatTab::EditUser( QString oldUser, QString newUser )
{
    RemoveUser(oldUser);
    AddUser(newUser);

}

void ChatTab::on_txtChat_returnPressed()
{
    talkWindow->SendMessage(channel, ui->txtChat->text() );
    ui->txtChat->clear();
}
