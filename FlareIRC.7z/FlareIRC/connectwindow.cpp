#include "connectwindow.h"
#include "ui_connectwindow.h"
#include "talkwindow.h"

ConnectWindow::ConnectWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::ConnectWindow)
{
    ui->setupUi(this);
}

ConnectWindow::~ConnectWindow()
{
    delete ui;
}

void ConnectWindow::changeEvent(QEvent *e)
{
    QMainWindow::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}

void ConnectWindow::on_btnConnect_clicked()
{
    TalkWindow *win = new TalkWindow(this);
    win->show();
    //close();
}

void ConnectWindow::on_btnCancel_clicked()
{
    exit(1);
}
