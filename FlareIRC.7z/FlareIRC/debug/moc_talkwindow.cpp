/****************************************************************************
** Meta object code from reading C++ file 'talkwindow.h'
**
** Created: Sun 20. Dec 03:02:01 2009
**      by: The Qt Meta Object Compiler version 62 (Qt 4.6.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../talkwindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'talkwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.6.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_TalkWindow[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      18,   12,   11,   11, 0x08,
      53,   11,   11,   11, 0x08,
      78,   74,   11,   11, 0x08,
     105,   11,   11,   11, 0x08,
     136,  121,   11,   11, 0x08,
     194,  171,   11,   11, 0x08,
     261,  235,   11,   11, 0x08,
     320,  309,   11,   11, 0x08,
     382,  356,   11,   11, 0x08,
     445,  431,   11,   11, 0x08,
     507,  479,   11,   11, 0x08,
     563,  549,   11,   11, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_TalkWindow[] = {
    "TalkWindow\0\0index\0on_tabChats_tabCloseRequested(int)\0"
    "on_btnJoin_clicked()\0msg\0"
    "IRC_ServerMessage(QString)\0IRC_Connected()\0"
    "source,channel\0IRC_JoinedChannel(QString,QString)\0"
    "source,channel,quitMsg\0"
    "IRC_LeftChannel(QString,QString,QString)\0"
    "source,channel,whom,modes\0"
    "IRC_ModeChange(QString,QString,QString,QString)\0"
    "source,msg\0IRC_PrivateMessage(QString,QString)\0"
    "source,context,msg,action\0"
    "IRC_ChannelMessage(QString,QString,QString,bool)\0"
    "channel,users\0IRC_UserList(QString,QStringList)\0"
    "source,channel,whom,message\0"
    "IRC_Kick(QString,QString,QString,QString)\0"
    "channel,topic\0IRC_ChannelTopic(QString,QString)\0"
};

const QMetaObject TalkWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_TalkWindow,
      qt_meta_data_TalkWindow, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &TalkWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *TalkWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *TalkWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_TalkWindow))
        return static_cast<void*>(const_cast< TalkWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int TalkWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: on_tabChats_tabCloseRequested((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: on_btnJoin_clicked(); break;
        case 2: IRC_ServerMessage((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: IRC_Connected(); break;
        case 4: IRC_JoinedChannel((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 5: IRC_LeftChannel((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 6: IRC_ModeChange((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4]))); break;
        case 7: IRC_PrivateMessage((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 8: IRC_ChannelMessage((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4]))); break;
        case 9: IRC_UserList((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QStringList(*)>(_a[2]))); break;
        case 10: IRC_Kick((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4]))); break;
        case 11: IRC_ChannelTopic((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        default: ;
        }
        _id -= 12;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
