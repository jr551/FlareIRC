/********************************************************************************
** Form generated from reading UI file 'talkwindow.ui'
**
** Created: Sun 20. Dec 02:36:17 2009
**      by: Qt User Interface Compiler version 4.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TALKWINDOW_H
#define UI_TALKWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QFrame>
#include <QtGui/QHeaderView>
#include <QtGui/QLineEdit>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QTabWidget>
#include <QtGui/QTextEdit>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TalkWindow
{
public:
    QWidget *centralwidget;
    QTabWidget *tabChats;
    QWidget *tbServer;
    QTextEdit *txtServerMessages;
    QFrame *frame;
    QPushButton *btnJoin;
    QLineEdit *txtChannelJoin;
    QMenuBar *menubar;
    QMenu *menuOptions;
    QMenu *menuHelp;

    void setupUi(QMainWindow *TalkWindow)
    {
        if (TalkWindow->objectName().isEmpty())
            TalkWindow->setObjectName(QString::fromUtf8("TalkWindow"));
        TalkWindow->resize(599, 411);
        centralwidget = new QWidget(TalkWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        tabChats = new QTabWidget(centralwidget);
        tabChats->setObjectName(QString::fromUtf8("tabChats"));
        tabChats->setGeometry(QRect(0, 0, 591, 351));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(tabChats->sizePolicy().hasHeightForWidth());
        tabChats->setSizePolicy(sizePolicy);
        tabChats->setDocumentMode(false);
        tabChats->setTabsClosable(true);
        tabChats->setMovable(true);
        tbServer = new QWidget();
        tbServer->setObjectName(QString::fromUtf8("tbServer"));
        txtServerMessages = new QTextEdit(tbServer);
        txtServerMessages->setObjectName(QString::fromUtf8("txtServerMessages"));
        txtServerMessages->setGeometry(QRect(0, 0, 581, 321));
        tabChats->addTab(tbServer, QString());
        frame = new QFrame(centralwidget);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(420, 360, 171, 31));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        btnJoin = new QPushButton(frame);
        btnJoin->setObjectName(QString::fromUtf8("btnJoin"));
        btnJoin->setGeometry(QRect(120, 0, 41, 23));
        txtChannelJoin = new QLineEdit(frame);
        txtChannelJoin->setObjectName(QString::fromUtf8("txtChannelJoin"));
        txtChannelJoin->setGeometry(QRect(0, 0, 113, 20));
        TalkWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(TalkWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 599, 21));
        menuOptions = new QMenu(menubar);
        menuOptions->setObjectName(QString::fromUtf8("menuOptions"));
        menuHelp = new QMenu(menubar);
        menuHelp->setObjectName(QString::fromUtf8("menuHelp"));
        TalkWindow->setMenuBar(menubar);

        menubar->addAction(menuOptions->menuAction());
        menubar->addAction(menuHelp->menuAction());

        retranslateUi(TalkWindow);

        tabChats->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(TalkWindow);
    } // setupUi

    void retranslateUi(QMainWindow *TalkWindow)
    {
        TalkWindow->setWindowTitle(QApplication::translate("TalkWindow", "MainWindow", 0, QApplication::UnicodeUTF8));
        tabChats->setTabText(tabChats->indexOf(tbServer), QApplication::translate("TalkWindow", "Server", 0, QApplication::UnicodeUTF8));
        btnJoin->setText(QApplication::translate("TalkWindow", "Join", 0, QApplication::UnicodeUTF8));
        txtChannelJoin->setText(QApplication::translate("TalkWindow", "#", 0, QApplication::UnicodeUTF8));
        menuOptions->setTitle(QApplication::translate("TalkWindow", "Options", 0, QApplication::UnicodeUTF8));
        menuHelp->setTitle(QApplication::translate("TalkWindow", "Help", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class TalkWindow: public Ui_TalkWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TALKWINDOW_H
