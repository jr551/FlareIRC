/********************************************************************************
** Form generated from reading UI file 'chattab.ui'
**
** Created: Sun 20. Dec 02:36:17 2009
**      by: Qt User Interface Compiler version 4.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHATTAB_H
#define UI_CHATTAB_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLineEdit>
#include <QtGui/QListView>
#include <QtGui/QTextEdit>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ChatTab
{
public:
    QLineEdit *txtChat;
    QTextEdit *txtMessages;
    QListView *lstUsers;

    void setupUi(QWidget *ChatTab)
    {
        if (ChatTab->objectName().isEmpty())
            ChatTab->setObjectName(QString::fromUtf8("ChatTab"));
        ChatTab->resize(537, 291);
        txtChat = new QLineEdit(ChatTab);
        txtChat->setObjectName(QString::fromUtf8("txtChat"));
        txtChat->setGeometry(QRect(10, 270, 521, 20));
        txtMessages = new QTextEdit(ChatTab);
        txtMessages->setObjectName(QString::fromUtf8("txtMessages"));
        txtMessages->setGeometry(QRect(10, 10, 371, 251));
        txtMessages->setReadOnly(true);
        lstUsers = new QListView(ChatTab);
        lstUsers->setObjectName(QString::fromUtf8("lstUsers"));
        lstUsers->setGeometry(QRect(390, 0, 141, 261));
        QSizePolicy sizePolicy(QSizePolicy::Ignored, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(lstUsers->sizePolicy().hasHeightForWidth());
        lstUsers->setSizePolicy(sizePolicy);

        retranslateUi(ChatTab);

        QMetaObject::connectSlotsByName(ChatTab);
    } // setupUi

    void retranslateUi(QWidget *ChatTab)
    {
        ChatTab->setWindowTitle(QApplication::translate("ChatTab", "Form", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class ChatTab: public Ui_ChatTab {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHATTAB_H
