#ifndef TALKWINDOW_H
#define TALKWINDOW_H

#include <QMainWindow>
#include "ircsocket.h"

namespace Ui {
    class TalkWindow;
}

class TalkWindow : public QMainWindow {
    Q_OBJECT
public:
    TalkWindow(QWidget *parent = 0);
    ~TalkWindow();

    void SendMessage( QString channel, QString message );


protected:
    void changeEvent(QEvent *e);
    QWidget* FindTabForChannel( QString channel );
private:
    Ui::TalkWindow *ui;
    IRCConnection   *ircConnection;
private slots:
    void on_tabChats_tabCloseRequested(int index);
    void on_btnJoin_clicked();
    void IRC_ServerMessage( QString msg );
    void IRC_Connected();
    void IRC_JoinedChannel( QString source, QString channel );

    void IRC_LeftChannel( QString source, QString channel, QString quitMsg  );
    void IRC_ModeChange( QString source, QString channel, QString whom, QString modes  );
    void IRC_PrivateMessage( QString source, QString msg );
    void IRC_ChannelMessage( QString source, QString context, QString msg, bool action );
    void IRC_UserList( QString channel, QStringList users);
    void IRC_Kick( QString source, QString channel, QString whom, QString message );
    void IRC_ChannelTopic( QString channel, QString topic);
};

#endif // TALKWINDOW_H
